import express from "express";
import { dirname } from "path";
import { fileURLToPath } from "url";
import bodyParser from "body-parser";
import pg from "pg";
const __dirname = dirname(fileURLToPath(import.meta.url));

const db = new pg.Client({
    user: "postgres",
    host: "localhost",
    database: "computerstore",
    password: "@V7QB##V/vUVm*hP*d",
    port: 5432
});
  
const app = express();
const port = 8080;

db.connect();


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

async function checkEmail() {
    const result = await db.query("SELECT emailaddress FROM accounts");
  
    const emails = [];
    result.rows.forEach((account) => {
        emails.push(account.emailaddress);
    });
  
    return emails;
}

app.get("/", (req, res) => {
    res.sendFile(__dirname + "/public/index.html");
});

app.post("/add", async (req, res) => {

    const newUser = [];
    newUser.push(req.body["inputName"]);
    newUser.push(req.body["inputEmail"]);
    newUser.push(req.body["inputPhoneNumber"]);
    newUser.push(req.body["inputAge"]);
    newUser.push(req.body["inputAddress"]);

    const query = `INSERT INTO accounts (name, emailaddress, phonenumber, age, address) VALUES ($1, $2, $3, $4, $5);`

        
    db.query(query, newUser)
        .then( rec => {
            console.log("Data inserted:", rec);
                    
            res.redirect("/userSignIn.html");
        })
        .catch(err => {
            console.error("Error inserting data:", err);
            res.send("<html><link rel='stylesheet' href='./styles/style.css'><body><h1>An account with the same email address already exists!</h1><br><br><a href='./userSignIn.html'><button style='height: 50px; width: 100px; font-size: 18pt'>Return</button></a></body></html>");
        });
 
});

app.listen(port, () => {
    console.log(`Listening on port ${port}`);
});

app.get("/dellinfo", productInfo);
app.get("/lenovoinfo", productInfo);
app.get("/hpinfo", productInfo);

async function productInfo(req, res){

    const result = await db.query("SELECT description, productcategory, productunitofmeasurement, productprice FROM products");
  
    const products = {};
    result.rows.forEach((product) => {
        if( req.url == "/dellinfo" && product.productcategory == "Dell"){
            products["description"] = product.description;
            products["category"] = product.productcategory;
            products["unitofmeasurement"] = product.productunitofmeasurement;
            products["price"] = product.productprice;
        }
        if( req.url == "/lenovoinfo" && product.productcategory == "Lenovo"){
            products["description"] = product.description;
            products["category"] = product.productcategory;
            products["unitofmeasurement"] = product.productunitofmeasurement;
            products["price"] = product.productprice;
        }
        if( req.url == "/hpinfo" && product.productcategory == "HP"){
            products["description"] = product.description;
            products["category"] = product.productcategory;
            products["unitofmeasurement"] = product.productunitofmeasurement;
            products["price"] = product.productprice;
        }
    });
    
       res.render("products.ejs", products);    
}

app.get("/purchase", purchaseProduct);

async function purchaseProduct(req, res) {

    const newPurchase = [];
    newPurchase.push(req.query.price);

    const query = `INSERT INTO purchases (purchasedate, purchaseprice) VALUES (current_date, $1);`;
 
    db.query(query, newPurchase)
    .then( rec => {
        console.log("Data inserted:", rec);
                
        res.send("<html><link rel='stylesheet' href='./styles/style.css'><body><h1>Thank you for your purchase!</h1><br><br><a href='./index.html'><button style='height: 50px; width: 100px; font-size: 18pt'>Return</button></a></body></html>");
    })
    .catch(err => {
        console.error("Error inserting data:", err);
    });   
}