CREATE TABLE accounts(
    id serial primary key NOT NULL,
    name VARCHAR(50) NOT NULL,
    emailaddress VARCHAR(50) NOT NULL,
    phonenumber bigint NOT NULL,
    age integer NOT NULL,
    address VARCHAR(100) NOT NULL,
)

CREATE TABLE products(
    id serial primary key NOT NULL ,
    description VARCHAR(500) NOT NULL,
    productcategory VARCHAR(200) NOT NULL,
    productunitofmeasurement VARCHAR(20) NOT NULL,
    productprice decimal NOT NULL
)

CREATE TABLE purchases(
    id serial primary key NOT NULL,
    purchasedate date NOT NULL,
    purchaseprice numeric NOT NULL
)